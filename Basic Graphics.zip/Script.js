// drawing basics
// button event
document.getElementById("btn").addEventListener("click", windows);
// set up canvas and graphics context
let cnv = document.getElementById("myCanvas");
// canvas number 1
let ctx = cnv.getContext("2d");
// canvas number 2
let cnv2 = document.getElementById("myCanvas2");
// context for 2d
let ctx2 = cnv2.getContext("2d");
// cloud image variable
let image = document.getElementById("cloud");

// canvas 1
cnv.height = 400;
cnv.width = 400;
// sky background
ctx.fillStyle = "blue";
ctx.fillRect(0, 0, 400, 400);
// draws ball
ctx.fillStyle = "red";
ctx.lineWidth = 5;
ctx.beginPath();
ctx.arc(200, 300, 15, 0, 2 * Math.PI);
ctx.fill();
// grass
ctx.fillStyle = "green";
ctx.fillRect(0, 300, 400, 100);
// clouds
ctx.drawImage(image, 120, 120);
ctx.drawImage(image, 140, 100);

// canvas 2
// canvas height
cnv2.height = 800;
cnv2.width = 500;
// background
ctx2.fillStyle = "blue";
ctx2.fillRect(0, 0, 500, 800);
// building
ctx2.fillStyle = "black";
ctx2.fillRect(0, 500, 800, 800);
// building
ctx2.fillStyle = "black";
ctx2.fillRect(25, 260, 200, 250);
// draws triangle for roof
ctx2.fillStyle = "black"
ctx2.beginPath();
ctx2.moveTo(225, 100); // start at (x1, y1)
ctx2.lineTo(225, 260); // go to (x2, y2)
ctx2.lineTo(25, 260); // go to (x3,y3)
ctx2.fill();

// buildings
ctx2.fillStyle = "black"
ctx2.fillRect(300, 100, 400, 400);
// buildings
ctx2.fillStyle = "black"
ctx2.fillRect(330, 70, 140, 30);
// buildings
ctx2.fillStyle = "black"
ctx2.fillRect(360, 40, 80, 30);

// function that makes windows
function windows() {
    // draws windows, by changing x, and y positions
    for (let x = 50; x <= 200; x += 45) {
        for (let y = 260; y <= 450; y += 35) {
            for (let w = 0; w <= 4; w++) {
                ctx2.fillStyle = "yellow";
                ctx2.fillRect(x, y, 20, 15);
            }
        }
    }
    // draws windows, by changing x, and y positions
    for (let x2 = 330; x2 <= 470; x2 += 30) {
        for (let y2 = 135; y2 <= 650; y2 += 35) {
            for (let w2 = 0; w2 <= 4; w2++) {
                ctx2.fillStyle = "yellow";
                ctx2.fillRect(x2, y2, 15, 100);
            }
        }
    }
    // draws windows, by changing x, and y positions
    for (let x3 = 40; x3 <= 170; x3 += 20) {
        for (let y3 = 500; y3 <= 725; y3 += 45) {
            for (let w3 = 0; w3 <= 4; w3++) {
                ctx2.fillStyle = "yellow";
                ctx2.fillRect(x3, y3, 50, 20);
            }
        }
    }
}